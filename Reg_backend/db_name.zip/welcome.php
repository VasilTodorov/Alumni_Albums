<html>
<body>
<!-- Add in database -->
<!-- make use of AJAX to write wrong registration existing username-->
<!-- personal profill -->

<?php

require 'dataBase.php'; 

function insert($username, $password)
{
    $dataBase = new Db();
    $sql = "INSERT INTO reg (username, password) VALUES (:username, :password)";
    
    // Use prepared statement to prevent SQL injection
    $stmt = $dataBase->getConnection()->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    
    // Execute the statement
    $stmt->execute();
}

// Assuming you have a form with method="post" and fields with name="username" and name="password"
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     insert($_POST["username"], $_POST["password"]);
// }
// header("Location: home-page.html");

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $dataBase = new Db();
    $username = $_POST['username'];
    //$password = $_POST["password"];

    $sql = "SELECT * FROM reg WHERE username = '$username'";
    $stmt = $dataBase->getConnection()->prepare($sql);
    //$stmt->bindParam(':username', $username);
    $stmt->execute();

    //$query = $dataBase->getConnection()->query($sql) or die("failed!");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row['username']) {        
        header("Location: public_html/registration_page.html?error=username_taken");//?error=username_taken
        exit();
    }
    else
    {
        insert($username, $_POST["password"]);
        header("Location: public_html/home-page.html");
        exit();
    }
}
?>


</body>
</html>