/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */


function extra(event) {
    // Prevent the default form submission behavior
    event.preventDefault();

    // Submit the form asynchronously using JavaScript
    var form = event.target;
    var formData = new FormData(form);

    // Perform the form submission using AJAX or fetch API
    fetch(form.action, {
        method: form.method,
        body: formData
    })
    .then(response => {
        if (response.ok) {
            // If the form submission was successful, navigate to "home-page.html"
            window.location.href = "home-page.html";
        } else {
            // Handle errors if needed
            console.error("Form submission failed");
        }
    })
    .catch(error => {
        // Handle network or other errors
        console.error("Error during form submission", error);
    });
};