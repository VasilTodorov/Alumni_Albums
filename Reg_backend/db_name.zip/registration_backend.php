<html>
<body>
    Hello
<?php
require 'dataBase.php'; 

function insert($real_name, $family_name, $email, $username,
 $group_class, $stream, $faculty_number, $speciality, $password)
{
    $dataBase = new Db();
    $sql = "INSERT INTO reg_new (real_name, family_name, email, username,
     group_class, stream, faculty_number, speciality, password) 
    VALUES (:real_name, :family_name, :email, :username, :group_class,
    :stream, :faculty_number, :speciality, :password)";
    
    // Use prepared statement to prevent SQL injection
    $stmt = $dataBase->getConnection()->prepare($sql);
    $stmt->bindParam(':real_name', $real_name);
    $stmt->bindParam(':family_name', $family_name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':group_class', $group_class);
    $stmt->bindParam(':stream', $stream);
    $stmt->bindParam(':faculty_number', $faculty_number);
    $stmt->bindParam(':speciality', $speciality);
    $stmt->bindParam(':password', $password);
    // Execute the statement
    $stmt->execute();
}

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    insert($_POST['real_name'], $_POST['family_name'], $_POST['email'], 
    $_POST['username'], $_POST['group_class'],
    $_POST['stream'], $_POST['faculty_number'], $_POST['speciality'], 
    $_POST['password']);

    header("Location: public_html/home-page.html");
}
?>
</body>
</html>