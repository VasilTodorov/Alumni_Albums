<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION["username"])) {
    header("Location: registration_page.html");
    exit();
}

// Fetch and display additional user information from the database if needed
require 'dataBase.php'; 


// Assuming getUserInfo is a method in your DB class that retrieves user information
$userInfo = getUserInfo($_SESSION["username"]);

// Display user information using HTML
?>

<!DOCTYPE html>
<html lang="bg">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content="Профил, в който всеки потребител може да промени данните си и да види някаква статистика за себе си" />

	<title>Профил страница</title>

	<link rel="stylesheet" type="text/css" href="style-account-page.css">
	<link rel="stylesheet" type="text/css" href="backgraund-effect-animation-1.css">
	
	<script src="script.js"></script>


</head>
<body>
		<div class="gradient-bg">
		<div class="gradients-container">

			<div>
				<nav class="nav-bar">
					<div class="logo">
						<a href="home-page.html"><img src="logo.png" class="logo"></a>
					</div>

					<ul class="ul-nav-bar">
						<li class="li-nav-bar"><a href="concerts-page.html">Концерти</a></li>
						<li class="li-nav-bar"><a href="culture-page.html">Култура</a></li>
						<li class="li-nav-bar"><a href="sport-page.html">Спорт</a></li>
						<li class="li-nav-bar"><a href="it-meets-page.html">IT Срещи</a></li>
					</ul>

					<div class="account">
						<a href="account.html"><img src="girl-account-profile.jpg" class="account"></a>
					</div>

				</nav>
			</div>

			<div class="account-header-wapper">
				<header></header>
				<div class="account-cols-container">
					<div class="account-left-col">
						<div class="account-img-container">
							<img src="girl-account-profile.jpg">
							<span></span>
						</div>

						<h3><?php echo $userInfo["first_name"]." ".$userInfo["last_name"] ; ?></h3>
						<p><?php echo "Специалност: ".$userInfo["major"]."<br>"."Випуск: ".$userInfo["graduation"]." Поток: ".$userInfo["stream"] ; ?></p>

						<ul class="account-about">
							<li><span>983</span> Посетени</li>
							<li><span>23</span> Предстоят</li>
							<li><span>33</span> Организирани</li>
						</ul>

						<div class="account-content">
							<p>Аз съм студентка във ФМИ. Работя като ловец на дъги 🌈. Хобитата ми са: програмиране, решаване на задачи и графичен дизайн. Обичам да готвя, пътувам и събирам антични монети.</p>

							<ul>
								<li>Twitter</li>
								<li>Facebook</li>
								<li>Instagram</li>
							</ul>
						</div>
					</div>

					<div class="account-right-col">
						<nav>
							<ul>
								<li><a>Галерия</a></li>
								<li><a>Посетени</a></li>
								<li><a>Предстои</a></li>
								<li><a>Организирани</a></li>
							</ul>
							<button>Редактирай</button>
						</nav>

						<div class="account-photos">
							<img src="concert/concert-1.jpg" >
							<img src="concert/concert-2.jpg" >
							<img src="concert/concert-3.jpg" >
							<img src="concert/concert-4.jpg" >
							<img src="concert/concert-1.jpg" >
							<img src="concert/concert-2.jpg" >
						</div>


					</div>
				</div>
			</div>


			
			<div class="g1"></div>
			<div class="g2"></div>
			<div class="g3"></div>
			<div class="g4"></div>
			<div class="g5"></div>
</div>
</div>
</body>
</html>